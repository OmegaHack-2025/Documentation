import { z } from "zod";
import { config } from "./config";

export const WebhookValidationModel = z.object({
  mode: z.literal("subscribe"),
  token: z.literal(config.WEBHOOK_VERIFY_TOKEN),
  challenge: z.string(),
});

const MetadataSchema = z.object({
  display_phone_number: z.string(),
  phone_number_id: z.string(),
});

const ProfileSchema = z.object({
  name: z.string(),
});

const ContactSchema = z.object({
  profile: ProfileSchema,
  wa_id: z.string(),
});

const TextSchema = z.object({
  body: z.string(),
});

const ImageSchema = z.object({
  mime_type: z.string(),
  sha256: z.string(),
  id: z.string(),
  caption: z.string().optional(),
});

const AudioSchema = z.object({
  mime_type: z.string(),
  sha256: z.string(),
  id: z.string(),
  voice: z.boolean(),
});

const StickerSchema = z.object({
  mime_type: z.string(),
  sha256: z.string(),
  id: z.string(),
});

const NameSchema = z.object({
  first_name: z.string(),
  formatted_name: z.string(),
});

const PhoneSchema = z.object({
  phone: z.string(),
  wa_id: z.string(),
  type: z.string(),
});

const ContactCardSchema = z.object({
  name: NameSchema,
  phones: z.array(PhoneSchema),
});

const DocumentSchema = z.object({
  caption: z.string().optional(),
  filename: z.string(),
  mime_type: z.string(),
  sha256: z.string(),
  id: z.string(),
});

// Define the base message fields that all message types share
const BaseMessageSchema = z.object({
  from: z.string(),
  id: z.string(),
  timestamp: z.string(),
});

// Create specific message type schemas with the discriminator field
export const TextMessageSchema = BaseMessageSchema.extend({
  type: z.literal("text"),
  text: TextSchema,
});

export const ImageMessageSchema = BaseMessageSchema.extend({
  type: z.literal("image"),
  image: ImageSchema,
});

export const AudioMessageSchema = BaseMessageSchema.extend({
  type: z.literal("audio"),
  audio: AudioSchema,
});

export const StickerMessageSchema = BaseMessageSchema.extend({
  type: z.literal("sticker"),
  sticker: StickerSchema,
});

export const ContactsMessageSchema = BaseMessageSchema.extend({
  type: z.literal("contacts"),
  contacts: z.array(ContactCardSchema),
});

export const DocumentMessageSchema = BaseMessageSchema.extend({
  type: z.literal("document"),
  document: DocumentSchema,
});

// Combine all message types into a discriminated union
const MessageSchema = z.discriminatedUnion("type", [
  TextMessageSchema,
  ImageMessageSchema,
  AudioMessageSchema,
  StickerMessageSchema,
  ContactsMessageSchema,
  DocumentMessageSchema,
]);

const ValueSchema = z.object({
  messaging_product: z.string(),
  metadata: MetadataSchema,
  contacts: z.array(ContactSchema),
  messages: z.array(MessageSchema),
});

const ChangeSchema = z.object({
  value: ValueSchema,
  field: z.string(),
});

const EntrySchema = z.object({
  id: z.string(),
  changes: z.array(ChangeSchema).nonempty(),
});

const IncomingMessageSchema = z.object({
  object: z.string(),
  entry: z.array(EntrySchema).nonempty(),
});

const FacebookMediaAssetSchema = z.object({
  url: z.string(),
  mime_type: z.string(),
  sha256: z.string(),
  file_size: z.number(),
  id: z.number(),
  messaging_product: z.string(),
});

// Export type definitions based on the new schemas
export type Metadata = z.infer<typeof MetadataSchema>;
export type Profile = z.infer<typeof ProfileSchema>;
export type Contact = z.infer<typeof ContactSchema>;
export type Text = z.infer<typeof TextSchema>;
export type Image = z.infer<typeof ImageSchema>;
export type Audio = z.infer<typeof AudioSchema>;
export type Sticker = z.infer<typeof StickerSchema>;
export type Name = z.infer<typeof NameSchema>;
export type Phone = z.infer<typeof PhoneSchema>;
export type ContactCard = z.infer<typeof ContactCardSchema>;
export type Document = z.infer<typeof DocumentSchema>;
export type Message = z.infer<typeof MessageSchema>;
export type Value = z.infer<typeof ValueSchema>;
export type Change = z.infer<typeof ChangeSchema>;
export type Entry = z.infer<typeof EntrySchema>;
export type IncomingMessage = z.infer<typeof IncomingMessageSchema>;
export type FacebookMediaAsset = z.infer<typeof FacebookMediaAssetSchema>;

export const parseIncomingMessage = (data: unknown) => {
  return IncomingMessageSchema.safeParse(data);
};

export async function downloadMediaMessage(mediaId: string) {
  const serviceResponse = await fetch(`https://graph.facebook.com/v22.0/${mediaId}?access_token=${config.WHATSAPP_BUSINESS_API_KEY}`, {
    method: 'GET',
  });
  const mediaData = await serviceResponse.json();
  const mediaUrl = mediaData.url;
  const mediaResponse = await fetch(mediaUrl, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${config.WHATSAPP_BUSINESS_API_KEY}`,
    },
  });
  const mediaBuffer = await mediaResponse.blob();
  return { mediaUrl, mediaBuffer };
}

export async function downloadAudioMessage(message: z.infer<typeof AudioMessageSchema>) {
  const id = message.audio.id;
  return downloadMediaMessage(id);
}

export async function downloadImageMessage(message: z.infer<typeof ImageMessageSchema>) {
  const id = message.image.id;
  return downloadMediaMessage(id);
}

export async function downloadDocumentMessage(message: z.infer<typeof DocumentMessageSchema>) {
  const id = message.document.id;
  return downloadMediaMessage(id);
}