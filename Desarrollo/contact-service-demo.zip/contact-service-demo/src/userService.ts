import { db } from './database';
import { conversationUsers } from './schema';
import { eq } from 'drizzle-orm';

export const getUserByPhoneNumber = async (phoneNumber: string) => {
  const result = await db.select().from(conversationUsers).where(eq(conversationUsers.phoneNumber, phoneNumber));
  return result[0] || null;
};

export const createUser = async (phoneNumber: string) => {
  return await db.insert(conversationUsers).values({
    phoneNumber,
  }).returning();
};