import { db } from './database';
import { conversations, messages, users_summary } from './schema';
import { eq, desc, sql } from 'drizzle-orm';
import { getUserByPhoneNumber, createUser } from './userService';
import { generateResponse } from './anthropicService';
import { updateUserSummary } from './orchestratorService';

export const saveMessages = async (
  conversationId: number,
  content: string[],
  inputTokens: number,
  outputTokens: number,
  role: 'user' | 'assistant'
) => {
  return await db.transaction(async (tx) => {
    await tx.insert(messages).values(
      content.map((msg) => ({
        conversationId,
        content: msg,
        role,
      }))
    );

    await tx.update(conversations).set({
      inputTokens: sql`input_tokens + ${inputTokens}`,
      outputTokens: sql`output_tokens + ${outputTokens}`,
      lastMessageAt: sql`now()`,
    }).where(eq(conversations.id, conversationId));
  });
};

export const getConversationHistory = async (conversationId: number) => {
  const messageHistory = await db.select().from(messages)
    .where(eq(messages.conversationId, conversationId))
    .orderBy(messages.timestamp);

  return messageHistory.map(msg => ({
    role: msg.role as 'user' | 'assistant',
    content: msg.content
  }));
};

/**
 * Process an incoming text message
 */
export const handleIncomingTextMessage = async (phoneNumber: string, message: string) => {
  try {
    // Get or create user
    let user = await getUserByPhoneNumber(phoneNumber);

    if (!user) {
      const newUsers = await createUser(phoneNumber);
      user = newUsers[0];
    }

    // Get or create conversation
    let conversationId: number;
    const existingConversation = await db.select().from(conversations)
      .where(eq(conversations.userId, user.id))
      .orderBy(desc(conversations.createdAt))
      .limit(1);

    const now = new Date();
    const threeHoursAgo = new Date(now.getTime() - 3 * 60 * 60 * 1000);

    // if a conversation exists and the last message was sent within the last 3 hours, use that conversation
    if (existingConversation.length > 0 && existingConversation[0].lastMessageAt > threeHoursAgo) {
      conversationId = existingConversation[0].id;
    } else {
      const newConversation = await db.insert(conversations)
        .values({ userId: user.id })
        .returning();
      conversationId = newConversation[0].id;
    }

    // Save user message
    await saveMessages(conversationId, [message], 0, 0, 'user');

    // Get conversation
    const conversation = await db.select().from(conversations)
      .where(eq(conversations.id, conversationId))
      .limit(1);

    if (!conversation.length) {
      throw new Error(`Conversation not found: ${conversationId}`);
    }

    let agentState = conversation[0].agentState;
    let agentPersonality = conversation[0].agentPersonality;

    // Get conversation history
    const history = await getConversationHistory(conversationId);

    // Get user summary
    const userSummary = await db.select().from(users_summary)
      .where(eq(users_summary.userId, user.id))
      .limit(1);

    // Generate response
    const response = await generateResponse(
      history,
      agentState!,
      agentPersonality!,
      userSummary.length > 0 ? userSummary[0] : null,
      [] // No predefined goals, the agent will decide
    );

    // Handle tool calls from the response
    if (response.stop_reason === 'tool_use') {
      // Find all tool use blocks
      const toolUseCalls = response.content.filter(block => block.type === 'tool_use');

      for (const toolUse of toolUseCalls) {
        const toolName = toolUse.name;
        const toolInput = toolUse.input as Record<string, string>;

        console.log(`Tool Used: ${toolName}`);
        console.log(`Tool Input: ${JSON.stringify(toolInput)}`);

        // Process based on tool type
        switch (toolName) {
          case 'updateUserSummary':
            // Update user summary with the provided information
            await updateUserSummary(user.id, toolInput);
            break;

          case 'suggestStateChange':
            // Update conversation state
            console.log(`Changing state to: ${toolInput.suggestedState} from ${agentState}`);
            await db.update(conversations)
              .set({ agentState: toolInput.suggestedState as any })
              .where(eq(conversations.id, conversationId));

            // Update local variable too
            agentState = toolInput.suggestedState as any;
            break;

          case 'suggestPersonalityChange':
            // Only change personality if current is NEUTRAL or specifically requested via test completion
            if (agentPersonality === 'NEUTRAL' ||
              (agentState === 'LEARNING_STYLE_TEST' && toolInput.suggestedPersonality !== 'NEUTRAL')) {
              await db.update(conversations)
                .set({ agentPersonality: toolInput.suggestedPersonality as any })
                .where(eq(conversations.id, conversationId));

              // Update local variable too
              agentPersonality = toolInput.suggestedPersonality as any;
            }
            break;

          case 'processLearningStyle':
            // Process learning style test results
            if (agentState === 'LEARNING_STYLE_TEST') {
              // Update personality based on dominant style
              await db.update(conversations)
                .set({
                  agentPersonality: toolInput.dominantStyle as any,
                  agentState: 'PERSONAL_HELP' // Return to normal contact state after test
                })
                .where(eq(conversations.id, conversationId));

              // Update local variables
              agentState = 'PERSONAL_HELP';
              agentPersonality = toolInput.dominantStyle as any;
            }
            break;
        }
      }

      // Generate a new response after handling tool calls, with updated state and personality
      // Don't use the same history as before since we want a fresh start with the new state
      const updatedConversation = await db.select().from(conversations)
        .where(eq(conversations.id, conversationId))
        .limit(1);

      if (updatedConversation.length > 0) {
        agentState = updatedConversation[0].agentState;
        agentPersonality = updatedConversation[0].agentPersonality;
      }

      // Get fresh history
      const updatedHistory = await getConversationHistory(conversationId);

      // Get updated user summary
      const updatedUserSummary = await db.select().from(users_summary)
        .where(eq(users_summary.userId, user.id))
        .limit(1);

      // Generate a new response with the updated state, personality, and user summary
      const newResponse = await generateResponse(
        [...updatedHistory, { role: 'assistant', content: `Se cambio el estado a ${agentState} y la personalidad a ${agentPersonality}, responda al usuario notificando el cambio, explique que se ha cambiado a ${agentPersonality} porque es la mejor opción para ayudarle a resolver sus dudas.` }],
        agentState!,
        agentPersonality!,
        updatedUserSummary.length > 0 ? updatedUserSummary[0] : null,
        [], // dont use goals
        true // Dont use tools
      );
      console.log('New response after tool calls:', newResponse);
      const finalContent = newResponse.content.filter((c) => 'text' in c).map((c) => c.text);
      console.log('Final Assistant response:', finalContent);
      await saveMessages(conversationId, finalContent, newResponse.usage.input_tokens, newResponse.usage.output_tokens, 'assistant');
      return finalContent;
    }

    // Save assistant response
    const content = response.content.filter((c) => 'text' in c).map((c) => c.text);
    console.log('Assistant response:', content);
    await saveMessages(conversationId, content, response.usage.input_tokens, response.usage.output_tokens, 'assistant');

    return content;
  } catch (error) {
    console.error('Error handling incoming message:', error);
    return ['Sorry, I encountered an error processing your message.'];
  }
};

