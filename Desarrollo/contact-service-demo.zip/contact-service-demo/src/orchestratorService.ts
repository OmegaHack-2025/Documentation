import { db } from './database';
import { users_summary } from './schema';
import { eq } from 'drizzle-orm';

// Types for user summary
export type UserSummary = {
  // Academic
  numberOfSubjects?: number;
  studyHoursPerWeek?: number;
  numberOfProjects?: number;
  projectComplexity?: number;
  understandsTopics?: boolean;

  // Psychological
  feltIsolated?: boolean;
  feltDisappointedByOthers?: boolean;
  feltCompetitionWithPeers?: boolean;
  feltUncomfortableSocially?: boolean;
  feltWorriedOrNervous?: boolean;
  feltDepressionOrSadness?: boolean;
  concentrationProblems?: boolean;
  feltAggressive?: boolean;
  selfDoubtFacingChallenges?: boolean;

  // Interpersonal
  talkedAboutProblems?: boolean;

  // Personal Health
  psychoactiveSubstanceUsePerWeek?: number;
  averageSleepHoursPerNight?: number;
  dailyMeals?: number;
  physicalActivityPerWeek?: number;
  socialMediaHoursPerDay?: number;
  headacheFrequency?: number;
  migraineFrequency?: number;
  digestionProblemsFrequency?: number;
  muscleRigidityFrequency?: number;
  tremorFrequency?: number;
};

/**
 * Create or update user summary
 */
export const updateUserSummary = async (userId: number, data: Partial<UserSummary>): Promise<boolean> => {
  try {
    // Check if user summary exists
    const existingSummary = await db.select().from(users_summary)
      .where(eq(users_summary.userId, userId))
      .limit(1);
      
    if (existingSummary.length === 0) {
      // Create new summary
      await db.insert(users_summary).values({
        userId,
        ...data
      });
    } else {
      // Update existing summary
      await db.update(users_summary)
        .set(data)
        .where(eq(users_summary.userId, userId));
    }
    
    return true;
  } catch (error) {
    console.error('Error updating user summary:', error);
    return false;
  }
};