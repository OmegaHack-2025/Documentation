import { relations } from 'drizzle-orm';
import { pgTable, text, integer, timestamp, serial, boolean } from 'drizzle-orm/pg-core';
import { pgEnum } from 'drizzle-orm/pg-core/columns/enum';

export const users_summary = pgTable('users_summary', {
  id: serial('id').primaryKey(),

  // Link to conversationUsers
  userId: integer('user_id').notNull().references(() => conversationUsers.id).unique(),

  // Academic
  numberOfSubjects: integer('number_of_subjects'),
  studyHoursPerWeek: integer('study_hours_per_week'),
  numberOfProjects: integer('number_of_projects'),
  projectComplexity: integer('project_complexity'),
  understandsTopics: boolean('understands_topics'),

  // Psychological
  feltIsolated: boolean('felt_isolated'),
  feltDisappointedByOthers: boolean('felt_disappointed_by_others'),
  feltCompetitionWithPeers: boolean('felt_competition_with_peers'),
  feltUncomfortableSocially: boolean('felt_uncomfortable_socially'),
  feltWorriedOrNervous: boolean('felt_worried_or_nervous'),
  feltDepressionOrSadness: boolean('felt_depression_or_sadness'),
  concentrationProblems: boolean('concentration_problems'),
  feltAggressive: boolean('felt_aggressive'),
  selfDoubtFacingChallenges: boolean('self_doubt_facing_challenges'),

  // Interpersonal
  talkedAboutProblems: boolean('talked_about_problems'),

  // Personal Health
  psychoactiveSubstanceUsePerWeek: integer('psychoactive_substance_use_per_week'),
  averageSleepHoursPerNight: integer('average_sleep_hours_per_night'),
  dailyMeals: integer('daily_meals'),
  physicalActivityPerWeek: integer('physical_activity_per_week'),
  socialMediaHoursPerDay: integer('social_media_hours_per_day'),
  headacheFrequency: integer('headache_frequency'),
  migraineFrequency: integer('migraine_frequency'),
  digestionProblemsFrequency: integer('digestion_problems_frequency'),
  muscleRigidityFrequency: integer('muscle_rigidity_frequency'),
  tremorFrequency: integer('tremor_frequency'),

  createdAt: timestamp('created_at').defaultNow(),
});


export const conversationUsers = pgTable('conversation_users', {
  id: serial('id').primaryKey(),
  phoneNumber: text('phone_number').notNull().unique(),
  createdAt: timestamp('created_at').defaultNow(),
});


export const agentState = pgEnum('agent_state', [
  "CONTACT", "LEARNING_STYLE_TEST", "ACADEMIC_HELP", "PERSONAL_HELP"]);

export const agentPersonality = pgEnum('agent_personality', ["NEUTRAL",
  "STRUCTURED_TEXTUAL", "CREATIVE_VISUAL", "NARRATIVE_AUDITIVE", "ACTIVE_CORPORAL"]);
  
export const conversations = pgTable('conversations', {
  id: serial('id').primaryKey(),
  agentState: agentState('state').default('CONTACT'),
  agentPersonality: agentPersonality('personality').default('STRUCTURED_TEXTUAL'),
  userId: integer('user_id').notNull().references(() => conversationUsers.id),
  createdAt: timestamp('created_at').defaultNow(),
  lastMessageAt: timestamp('last_message_at').notNull().defaultNow(),
  inputTokens: integer('input_tokens').default(0),  // Tracks input token usage
  outputTokens: integer('output_tokens').default(0), // Tracks output token usage
});

export const messages = pgTable('messages', {
  id: serial('id').primaryKey(),
  conversationId: integer('conversation_id').notNull().references(() => conversations.id),
  content: text('content').notNull(),
  role: text('role').notNull(), // 'user' or 'assistant'
  timestamp: timestamp('timestamp').defaultNow(),
});


export const conversationsRelations = relations(conversations, ({ one, many }) => ({
  conversationUser: one(conversationUsers, {
    fields: [conversations.userId],
    references: [conversationUsers.id],
  }),
  messages: many(messages),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  conversation: one(conversations, {
    fields: [messages.conversationId],
    references: [conversations.id],
  }),
}));

export const usersSummaryRelations = relations(users_summary, ({ one }) => ({
  user: one(conversationUsers, {
    fields: [users_summary.userId],
    references: [conversationUsers.id],
  }),
}));
