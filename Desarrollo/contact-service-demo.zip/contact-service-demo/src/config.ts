import 'dotenv/config';
import { z } from 'zod';

const ConfigSchema = z.object({
  PORT: z.preprocess((val) => Number(val) || 3000, z.number().int().positive()),
  DATABASE_URL: z.string().url(),
  DEFAULT_AGENT_ID: z.string(),
  WEBHOOK_VERIFY_TOKEN: z.string().nonempty(),
  WHATSAPP_BUSINESS_API_KEY: z.string().nonempty(),
  ANTHROPIC_API_KEY: z.string().nonempty(),
});

const parsedConfig = ConfigSchema.safeParse({
  PORT: process.env.PORT,
  DATABASE_URL: process.env.DATABASE_URL,
  DEFAULT_AGENT_ID: process.env.DEFAULT_AGENT_ID,
  WEBHOOK_VERIFY_TOKEN: process.env.WEBHOOK_VERIFY_TOKEN,
  WHATSAPP_BUSINESS_API_KEY: process.env.WHATSAPP_BUSINESS_API_KEY,
  ANTHROPIC_API_KEY: process.env.ANTHROPIC_API_KEY,
});

if (!parsedConfig.success) {
  console.error('Invalid configuration:', parsedConfig.error.format());
  process.exit(1);
}

export const config = parsedConfig.data;