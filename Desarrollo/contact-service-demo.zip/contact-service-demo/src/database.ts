import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';
import { config } from './config';
import * as schema from './schema';

// Create a PostgreSQL connection pool
const pool = new Pool({
  connectionString: config.DATABASE_URL,
});

// Create a Drizzle instance using the PostgreSQL pool
export const db = drizzle(pool, { schema });
