import { Hono } from 'hono'
import { config } from './config';
import { parseIncomingMessage, WebhookValidationModel } from './whatsapp';
import { handleIncomingTextMessage } from './conversationService';

const app = new Hono();

app.post('/webhook', async (c) => {
  const body = await c.req.json();
  const parsedMessage = parseIncomingMessage(body);
  if (!parsedMessage.success) {
    c.status(400);
    return c.body('Invalid message format');
  }
  const { entry } = parsedMessage.data;
  const messages = entry[0].changes[0].value.messages;
  const metadata = entry[0].changes[0].value.metadata;

  const businessPhoneNumberId = metadata.phone_number_id;

  const message = messages[0];
  console.log(message);
  await fetch(`https://graph.facebook.com/v22.0/${businessPhoneNumberId}/messages`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${config.WHATSAPP_BUSINESS_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      message_id: message.id,
      messaging_product: 'whatsapp',
      status: 'read',
    }),
  });
  let response: string[] = [];
  if (message.type === 'text') {
    const resp = await handleIncomingTextMessage(message.from, message.text.body);
    response.push(...resp);
  } else {
    response.push("I can only process text messages");
  }

  for (const resp of response) {
    const apiResponse = await fetch(`https://graph.facebook.com/v22.0/${businessPhoneNumberId}/messages`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${config.WHATSAPP_BUSINESS_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        messaging_product: 'whatsapp',
        to: message.from,
        text: { body: resp },
        context: {
          message_id: message.id,
        },
      }),
    });
    console.log('Response from WhatsApp API:', apiResponse.status, await apiResponse.text());
  }

  c.status(200);
  return c.json({ status: 'Message received' });
});

app.get('/webhook', (c) => {
  const request = WebhookValidationModel.safeParse({
    mode: c.req.query('hub.mode'),
    token: c.req.query('hub.verify_token'),
    challenge: c.req.query('hub.challenge'),
  });

  if (!request.success) {
    console.error('Invalid request:', request.error.format());
    c.status(403);
    return c.body('Forbidden');
  }
  const { challenge } = request.data;
  c.status(200);
  return c.body(challenge);
});

// Health check endpoint
app.get('/health', (c) => c.json({ status: 'ok' }));

export default app
