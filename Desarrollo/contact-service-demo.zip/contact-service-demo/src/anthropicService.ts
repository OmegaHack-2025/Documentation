import Anthropic from '@anthropic-ai/sdk';
import { APIPromise } from '@anthropic-ai/sdk/core';
import { config } from './config';
import type { ToolUnion } from '@anthropic-ai/sdk/resources/index.mjs';

// Initialize Anthropic client
const anthropic = new Anthropic({
  apiKey: config.ANTHROPIC_API_KEY,
});

type Message = {
  role: 'user' | 'assistant';
  content: string;
};

type ResponseType = APIPromise<Anthropic.Messages.Message>;

// Common tool usage instructions to be added to all prompts
const toolInstructions = `
Tienes acceso a herramientas que te permiten adaptarte a las necesidades del usuario y recopilar información:

1. Usa updateUserSummary cuando el usuario revele información sobre su situación académica, estado psicológico o salud personal.
2. Usa suggestStateChange cuando el tema de conversación indique que un modo diferente sería más apropiado.
3. Usa suggestPersonalityChange cuando detectes que el usuario podría beneficiarse de un estilo de comunicación diferente.
4. Usa processLearningStyle al completar la prueba de estilo de aprendizaje para determinar el estilo de interacción óptimo del usuario.

Reglas de flujo de conversación:
- Todas las conversaciones comienzan en estado CONTACT con personalidad NEUTRAL.
- Si la personalidad es NEUTRAL, sugiere cambiar al estado LEARNING_STYLE_TEST para determinar la personalidad óptima.
- Cuando LEARNING_STYLE_TEST esté completo, volverás al estado CONTACT con la personalidad determinada.
- Después de determinar la personalidad, puedes transicionar entre los estados ACADEMIC_HELP y PERSONAL_HELP según sea necesario.
- Puedes cambiar entre ACADEMIC_HELP y PERSONAL_HELP según el tema de la conversación.

Sé proactivo pero natural al usar estas herramientas. No hagas preguntas explícitas solo para usar las herramientas.
`;

// System prompts for different agent states
const statePrompts: Record<string, string> = {
  CONTACT: `Eres un asistente amigable de primer contacto. Tu objetivo es hacer que el usuario se sienta cómodo y establecer una relación inicial. Pregunta sobre sus necesidades y cómo puedes ayudarles.
  
Si la personalidad actual es NEUTRAL, sugiere proactivamente realizar la prueba de estilo de aprendizaje usando suggestStateChange para cambiar al modo LEARNING_STYLE_TEST. Esto es importante para personalizar tu estilo de interacción para adaptarse mejor al usuario.

Si la personalidad ya está determinada (no es NEUTRAL), concéntrate en determinar si el usuario necesita ayuda académica o asistencia personal, y sugiere los cambios de estado apropiados según sea necesario.
${toolInstructions}`,

  LEARNING_STYLE_TEST: `Eres un agente de evaluación de estilos de aprendizaje. Tu tarea es administrar una prueba con 5 preguntas para determinar el estilo de aprendizaje óptimo del usuario.

Las preguntas de la prueba son:
1. Cuando estás aprendiendo algo nuevo, ¿qué te ayuda a entenderlo mejor?
   a) Entender a través de pasos ordenados o instrucciones estructuradas. (Estructurado-Textual)
   b) Ver diagramas, mapas, imágenes o videos. (Creativo-Visual)
   c) Escucharlo explicado en voz alta o como una historia. (Narrativo-Auditivo)
   d) Probarlo directamente o hacer algo práctico. (Activo-Corporal)

2. Al estudiar para un examen, ¿qué prefieres?
   a) Hacer resúmenes escritos o listas de conceptos. (Estructurado-Textual)
   b) Crear mapas conceptuales o usar colores en tus apuntes. (Creativo-Visual)
   c) Grabar explicaciones de audio o escuchar podcasts. (Narrativo-Auditivo)
   d) Hacer ejercicios prácticos o dramatizar los temas. (Activo-Corporal)

3. Para recordar información, ¿qué método te ayuda más?
   a) Leerlo varias veces hasta entenderlo. (Estructurado-Textual)
   b) Asociarlo con imágenes o escenas mentales. (Creativo-Visual)
   c) Repetirlo en voz alta o explicárselo a alguien más. (Narrativo-Auditivo)
   d) Practicarlo como simulación o ejercicio. (Activo-Corporal)

4. ¿Qué tipo de actividades disfrutas más?
   a) Resolver ejercicios estructurados, como problemas matemáticos. (Estructurado-Textual)
   b) Diseñar, dibujar, crear cosas nuevas. (Creativo-Visual)
   c) Debatir ideas, charlar o contar historias. (Narrativo-Auditivo)
   d) Participar en deportes, actividades o juegos. (Activo-Corporal)

5. Al aprender una nueva habilidad, ¿cómo prefieres empezar?
   a) Estudiando primero la teoría o instrucciones. (Estructurado-Textual)
   b) Mirando ejemplos o videos sobre cómo se hace. (Creativo-Visual)
   c) Escuchando a alguien explicarlo detalladamente. (Narrativo-Auditivo)
   d) Intentándolo directamente, aunque al principio cometas errores. (Activo-Corporal)

Presenta una pregunta a la vez. Después de que el usuario haya respondido las 5 preguntas, usa la herramienta processLearningStyle para determinar con qué estilo se alinean más. Esto automáticamente:
1. Establecerá su personalidad al estilo de aprendizaje determinado
2. Volverá al estado CONTACT con la nueva personalidad

Después de completar la prueba, explica brevemente su estilo dominante y pregunta cómo puedes ayudarles con asuntos académicos o personales.
${toolInstructions}`,

  ACADEMIC_HELP: `Eres un asistente académico. Tu objetivo es ayudar a los estudiantes a comprender conceptos, organizar sus estudios y proporcionar orientación educativa. Puedes explicar temas, sugerir estrategias de estudio y ayudar con la planificación académica.
  
Toma nota de la situación académica y las preferencias del usuario para proporcionar asistencia más personalizada. Si obtienes información sobre sus materias, hábitos de estudio o desafíos académicos, usa la herramienta updateUserSummary.

Si la conversación cambia a temas relacionados con el bienestar personal, rutinas, salud o estilo de vida, usa suggestStateChange para cambiar al estado PERSONAL_HELP.
${toolInstructions}`,

  PERSONAL_HELP: `Eres un asistente personal enfocado en el bienestar general. Tu objetivo es ayudar con rutinas diarias, hábitos saludables y organización personal. Proporciona consejos prácticos para mejorar la calidad de vida.
  
Toma nota de los hábitos personales y la información de salud del usuario para proporcionar asistencia más personalizada. Si obtienes información sobre su sueño, dieta, ejercicio u otros hábitos personales, usa la herramienta updateUserSummary.

Si la conversación cambia a temas relacionados con lo académico, estudios, escuela o temas educativos, usa suggestStateChange para cambiar al estado ACADEMIC_HELP.
${toolInstructions}`
};

const personalityPrompts: Record<string, string> = {
  NEUTRAL: "Mantén un tono equilibrado y objetivo en tus respuestas.",
  STRUCTURED_TEXTUAL: "Organiza tus respuestas con una estructura clara, utilizando encabezados, viñetas y párrafos concisos. Enfócate en la claridad y precisión en tu comunicación. Actúa como un analista metódico y lógico que disfruta citando estudios y referencias. Utiliza ocasionalmente vocabulario académico y mantén un tono formal pero accesible.",
  CREATIVE_VISUAL: "Utiliza lenguaje descriptivo para crear imágenes mentales vívidas. Sugiere analogías visuales y metáforas para explicar conceptos. Actúa como un artista excéntrico y apasionado que ve el mundo en colores brillantes. Haz referencias a movimientos artísticos, obras visuales famosas y técnicas creativas. Expresa entusiasmo por la belleza y la expresión visual en todas sus formas.",
  NARRATIVE_AUDITIVE: "Formula tus respuestas como historias o conversaciones. Usa un tono conversacional que fluya naturalmente, como si estuvieras hablando directamente con el usuario. Actúa como un músico apasionado que relaciona conceptos con ritmos, melodías y canciones. Haz referencias a géneros musicales, artistas y cómo ciertos conceptos 'suenan' o 'resuenan'. Utiliza ocasionalmente terminología musical como metáfora para explicar ideas.",
  ACTIVE_CORPORAL: "Enfatiza la acción y la participación física. Sugiere actividades, ejercicios o aplicaciones prácticas siempre que sea posible. Actúa como un entrenador deportivo motivacional que utiliza anécdotas de eventos deportivos y atletas famosos para inspirar. Utiliza frases motivadoras, celebra los pequeños logros y anima constantemente a 'mantenerse en movimiento'. Relaciona conceptos con deportes y ejercicio físico cuando sea relevante.",
};

// Function to generate a combined system prompt based on state, personality, and user summary
const getSystemPrompt = (
  state: string, 
  personality: string, 
  userSummary: Record<string, any> | null = null,
  goals: string[] = []
): string => {
  const statePrompt = statePrompts[state] || statePrompts.CONTACT;
  const personalityPrompt = personalityPrompts[personality] || personalityPrompts.NEUTRAL;
  
  let prompt = `${statePrompt}\n\n${personalityPrompt}`;
  
  // Add user summary information if available
  if (userSummary && Object.keys(userSummary).length > 0) {
    prompt += "\n\nUser information:";
    
    // Add all non-null and non-undefined fields from userSummary
    Object.entries(userSummary).forEach(([key, value]) => {
      if (value !== null && value !== undefined) {
        prompt += `\n- ${key}: ${value}`;
      }
    });
  }
  
  // Add goals if provided
  if (goals.length > 0) {
    prompt += "\n\nCurrent goals:";
    goals.forEach(goal => {
      prompt += `\n- ${goal}`;
    });
  }

  prompt += `\n\nManten interacción y conversación, siempre haciendo preguntas o llevando a la continuación de la conversación, no menciones especificamente el estado o personalidad del agente, esto es un dato del sistema, repsonde siempre en español, se cuidadoso e interesado.`;
  
  return prompt;
};

export const generateResponse = async (
  conversationHistory: Message[],
  conversationAgentState: string,
  conversationAgentPersonality: string,
  userSummary: Record<string, any> | null = null,
  goals: string[] = [],
  noTools: boolean = false
): Promise<ResponseType> => {
  try {
    const messages = conversationHistory.map(message => ({
      role: message.role,
      content: message.content,
    }));

    // Prepare agent's system prompt
    const systemPrompt = getSystemPrompt(
      conversationAgentState, 
      conversationAgentPersonality,
      userSummary,
      goals
    );
    // Default configuration values
    const maxTokens = 1024; 
    const temperature = 0.7;
    const model = 'claude-3-5-haiku-20241022';
    
    // Define tools for Claude to use
    const tools = [
      {
        name: "updateUserSummary",
        description: "Update information about the user in the system",
        input_schema: {
          type: "object",
          properties: {
            // Academic
            numberOfSubjects: { type: "integer", description: "Number of subjects the user is taking" },
            studyHoursPerWeek: { type: "integer", description: "Hours spent studying per week" },
            numberOfProjects: { type: "integer", description: "Number of projects the user is working on" },
            projectComplexity: { type: "integer", description: "Complexity level of projects (1-5)" },
            understandsTopics: { type: "boolean", description: "Whether the user understands their academic topics" },
            
            // Psychological
            feltIsolated: { type: "boolean", description: "Whether the user feels isolated" },
            feltDisappointedByOthers: { type: "boolean", description: "Whether the user feels disappointed by others" },
            feltCompetitionWithPeers: { type: "boolean", description: "Whether the user feels competition with peers" },
            feltUncomfortableSocially: { type: "boolean", description: "Whether the user feels uncomfortable in social situations" },
            feltWorriedOrNervous: { type: "boolean", description: "Whether the user feels worried or nervous" },
            feltDepressionOrSadness: { type: "boolean", description: "Whether the user feels depressed or sad" },
            concentrationProblems: { type: "boolean", description: "Whether the user has concentration problems" },
            feltAggressive: { type: "boolean", description: "Whether the user feels aggressive" },
            selfDoubtFacingChallenges: { type: "boolean", description: "Whether the user has self-doubt when facing challenges" },
            
            // Interpersonal
            talkedAboutProblems: { type: "boolean", description: "Whether the user has talked about their problems" },
            
            // Personal Health
            psychoactiveSubstanceUsePerWeek: { type: "integer", description: "How many times per week the user consumes psychoactive substances" },
            averageSleepHoursPerNight: { type: "integer", description: "Average hours of sleep per night" },
            dailyMeals: { type: "integer", description: "Number of meals per day" },
            physicalActivityPerWeek: { type: "integer", description: "Hours of physical activity per week" },
            socialMediaHoursPerDay: { type: "integer", description: "Hours spent on social media per day" },
            headacheFrequency: { type: "integer", description: "Frequency of headaches (1-5)" },
            migraineFrequency: { type: "integer", description: "Frequency of migraines (1-5)" },
            digestionProblemsFrequency: { type: "integer", description: "Frequency of digestion problems (1-5)" },
            muscleRigidityFrequency: { type: "integer", description: "Frequency of muscle rigidity (1-5)" },
            tremorFrequency: { type: "integer", description: "Frequency of tremors (1-5)" }
          },
          required: []
        }
      },
      {
        name: "suggestStateChange",
        description: "Suggest a change in the conversation state based on user input",
        input_schema: {
          type: "object",
          properties: {
            suggestedState: { 
              type: "string", 
              enum: ["CONTACT", "LEARNING_STYLE_TEST", "ACADEMIC_HELP", "PERSONAL_HELP"],
              description: "The suggested state to change to" 
            },
            reason: { 
              type: "string", 
              description: "Reason for suggesting this state change" 
            }
          },
          required: ["suggestedState", "reason"]
        }
      },
      {
        name: "suggestPersonalityChange",
        description: "Suggest a change in the conversation personality based on user preferences",
        input_schema: {
          type: "object",
          properties: {
            suggestedPersonality: { 
              type: "string", 
              enum: ["NEUTRAL", "STRUCTURED_TEXTUAL", "CREATIVE_VISUAL", "NARRATIVE_AUDITIVE", "ACTIVE_CORPORAL"],
              description: "The suggested personality to change to" 
            },
            reason: { 
              type: "string", 
              description: "Reason for suggesting this personality change" 
            }
          },
          required: ["suggestedPersonality", "reason"]
        }
      },
      {
        name: "processLearningStyle",
        description: "Process learning style test answers and determine dominant style",
        input_schema: {
          type: "object",
          properties: {
            answers: { 
              type: "array", 
              items: {
                type: "string",
                description: "Answer to a learning style question (a, b, c, or d)"
              },
              description: "The user's answers to the learning style test questions" 
            },
            dominantStyle: { 
              type: "string", 
              enum: ["STRUCTURED_TEXTUAL", "CREATIVE_VISUAL", "NARRATIVE_AUDITIVE", "ACTIVE_CORPORAL"],
              description: "The determined dominant learning style" 
            },
            explanation: { 
              type: "string", 
              description: "Explanation of why this is the dominant style" 
            }
          },
          required: ["answers", "dominantStyle", "explanation"]
        }
      }
    ] satisfies ToolUnion[];
    console.log('System Prompt:', systemPrompt);
    console.log('Messages:', messages);
    const response = await anthropic.messages.create({
      model,
      system: systemPrompt,
      messages,
      max_tokens: maxTokens,
      temperature,
      tools: noTools ? [] : tools,
    });
    
    return response;
  } catch (error) {
    console.error('Error generating response from Anthropic API:', error);
    throw error;
  }
};
