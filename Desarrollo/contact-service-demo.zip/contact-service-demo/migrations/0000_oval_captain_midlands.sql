CREATE TYPE "public"."agent_personality" AS ENUM('NEUTRAL', 'STRUCTURED_TEXTUAL', 'CREATIVE_VISUAL', 'NARRATIVE_AUDITIVE', 'ACTIVE_CORPORAL');--> statement-breakpoint
CREATE TYPE "public"."agent_state" AS ENUM('CONTACT', 'LEARNING_STYLE_TEST', 'ACADEMIC_HELP', 'PERSONAL_HELP');--> statement-breakpoint
CREATE TABLE "conversation_users" (
	"id" serial PRIMARY KEY NOT NULL,
	"phone_number" text NOT NULL,
	"created_at" timestamp DEFAULT now(),
	CONSTRAINT "conversation_users_phone_number_unique" UNIQUE("phone_number")
);
--> statement-breakpoint
CREATE TABLE "conversations" (
	"id" serial PRIMARY KEY NOT NULL,
	"state" "agent_state" DEFAULT 'CONTACT',
	"personality" "agent_personality" DEFAULT 'STRUCTURED_TEXTUAL',
	"user_id" integer NOT NULL,
	"created_at" timestamp DEFAULT now(),
	"last_message_at" timestamp DEFAULT now() NOT NULL,
	"input_tokens" integer DEFAULT 0,
	"output_tokens" integer DEFAULT 0
);
--> statement-breakpoint
CREATE TABLE "messages" (
	"id" serial PRIMARY KEY NOT NULL,
	"conversation_id" integer NOT NULL,
	"content" text NOT NULL,
	"role" text NOT NULL,
	"timestamp" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "users_summary" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer NOT NULL,
	"number_of_subjects" integer,
	"study_hours_per_week" integer,
	"number_of_projects" integer,
	"project_complexity" integer,
	"understands_topics" boolean,
	"felt_isolated" boolean,
	"felt_disappointed_by_others" boolean,
	"felt_competition_with_peers" boolean,
	"felt_uncomfortable_socially" boolean,
	"felt_worried_or_nervous" boolean,
	"felt_depression_or_sadness" boolean,
	"concentration_problems" boolean,
	"felt_aggressive" boolean,
	"self_doubt_facing_challenges" boolean,
	"talked_about_problems" boolean,
	"psychoactive_substance_use_per_week" integer,
	"average_sleep_hours_per_night" integer,
	"daily_meals" integer,
	"physical_activity_per_week" integer,
	"social_media_hours_per_day" integer,
	"headache_frequency" integer,
	"migraine_frequency" integer,
	"digestion_problems_frequency" integer,
	"muscle_rigidity_frequency" integer,
	"tremor_frequency" integer,
	"created_at" timestamp DEFAULT now(),
	CONSTRAINT "users_summary_user_id_unique" UNIQUE("user_id")
);
--> statement-breakpoint
ALTER TABLE "conversations" ADD CONSTRAINT "conversations_user_id_conversation_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."conversation_users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "messages" ADD CONSTRAINT "messages_conversation_id_conversations_id_fk" FOREIGN KEY ("conversation_id") REFERENCES "public"."conversations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "users_summary" ADD CONSTRAINT "users_summary_user_id_conversation_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."conversation_users"("id") ON DELETE no action ON UPDATE no action;